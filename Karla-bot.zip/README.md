<img src="https://readme-typing-svg.herokuapp.com/?font=mono&size=30&duration=4000&color=FF00FF&center=falso&vCenter=falso&lines=𝐃𝐔𝐃𝐀-𝐁𝐀𝐒𝐄;𝑨𝖑𝖎𝖟𝖎𝖓-𝕯𝖊𝖛-𝕯𝖔𝖒𝖎𝖓𝖆𝖆✰✰✰✰✰">      
<h1 align="center">
<p>
<img src= "https://telegra.ph/file/b2d75aaaed21ed7b91d49.jpg" alt="DUDA BOT" width="720">
</p>

<p align="center">
<a href="#"><img title="BOT MULTI DEVICE" src="https://img.shields.io/badge/BOT MULTI DEVICE-blue?&style=for-the-badge"></a>
</p>

<p align="center">
<img title="Autor" src="https://img.shields.io/badge/Autor-ALIZIN.DEV-orange.svg?style=for-the-badge&logo=github"></a>
<img title="Versão" src="https://img.shields.io/badge/Versão-3.0.0-orange.svg?style=for-the-badge&logo=github"></a>
</p>

### <h3>Sem Servidor Para Deixar O Bot Em 24H/48H Online, Clica No Botão Abaixo:
   <br>
<a href="https://youtu.be/-Rqmm8xS90o">0 - Site Da Replit (Video Ensinando)</a>
  </br>
</h3>
</div>

## INSTALAÇÃO VIA TERMUX  <img src="https://user-images.githubusercontent.com/108157095/182052725-6568419a-6a9f-490a-85ea-90b94af694fe.png" height="25px">
**1° COMANDO ( PERMISSÃO )**
```
termux-setup-storage
```
---------------------------
**2° COMANDO ( PERMISSÃO PRA PODER INSTALAR )**
```
pkg install git -y
```
**3° COMANDO ( ENTRAR NA PASTA )**
```
cd /sdcard/
```
**4° COMANDO ( INSTALAÇÃO DO BOT )**
```
git clone https://github.com/alizin-dev/duda-base.git
```
**5° COMANDO ( ENTRAR NA PASTA DO BOT )**
```
cd duda-base
```
**6° COMANDO ( INSTALAÇÃO,dependências para o bot funfar )**
```
sh instalacao.sh
```

## SE O TERMUX FECHOU, DIGITE; <img src="https://user-images.githubusercontent.com/108157095/182053901-78e4a217-51ba-42a3-8ec5-38ed978ad752.png" height="25px">
```
cd /sdcard/duda-base && sh alizin.sh
```
 ### <h2 align="center">❗ UTILIZE O CMD: sh atualizar.sh</h2>

```
USE O CMD " sh atualizar.sh "
ESSE COMANDO SERVE PARA QUANDO TIVER UMA ATUALIZAÇÃO, E VC VIU QUE TEM UMA ATUALIZAÇÃO.
VC VAI USAR ESSE CMD! VC VAI NO TERMUX E DIGITA " CTRL C ", CLICA NO CTRL E DPS NA LETRA C
E DIGITE: sh atualizar.sh 
PRONTO. O BOT VAI SE AUTO-ATUALIZAR!
```


```
sh atualizar.sh
```
 ### <h2 align="center">❗ UTILIZE O CMD: sh gerarqr.sh</h2>
```
USE O CMD " sh gerarqr.sh "
ESSE COMANDO SERVE PARA QUANDO VOCÊ QUISER/QUERER GERAR OUTRO QRCODE,E COMO SE DIZ O NOME, VAI GERAR OUTRO QRCODE.
VC VAI USAR ESSE CMD! VC VAI NO TERMUX E DIGITA " CTRL C ", CLICA NO CTRL E DPS NA LETRA C
E DIGITE: sh gerarqr.sh 
PRONTO. O BOT VAI APAGAR O QRCODE E DPS VAI SE AUTO-ATUALIZAR!
```

```
sh gerarqr.sh
```
### <h2 align="center">⚙️ INSTRUÇÕES</h2>

   
### • Escaneie o qr code por outro celular na aba de "APARELHOS CONECTADOS".
  
### • Certifique-se que seu Whatsapp esteja atualizado. (recomendo, use o da play store:WHATSAPP BUNNESIS).

### • Quando Desligar o bot e quiser ligar novamente basta digitar : 
```
cd /sdcard/duda-base && sh alizin.sh
```
### • Vá no arquivo 'CONFIGURACAO.JS' e coloque seu número no lugar do jeito q esta la, no mesmo formato, JAE CHEF ?
 
### • mude o prefixo tbm ( SE QUISER ). no arquivo > 'CONFIGURACAO.JS'
 



 <img src="https://readme-typing-svg.herokuapp.com/?font=mono&size=30&duration=4000&color=00FFFF&center=falso&vCenter=falso&lines=𝑨𝖑𝖎𝖟𝖎𝖓-𝕯𝖊𝖛-𝕯𝖔𝖒𝖎𝖓𝖆𝖆✰✰✰✰✰">      


## DEIXEMM OS CRÉDITOS 😈
